package modelo;

public interface Reserva {
    double darPrecio();
    String tipo();
}
