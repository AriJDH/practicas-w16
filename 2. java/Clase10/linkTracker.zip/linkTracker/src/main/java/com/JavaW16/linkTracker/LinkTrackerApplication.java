package com.JavaW16.linkTracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LinkTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LinkTrackerApplication.class, args);
	}

}
