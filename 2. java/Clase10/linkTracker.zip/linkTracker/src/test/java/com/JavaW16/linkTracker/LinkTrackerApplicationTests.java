package com.JavaW16.linkTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinkTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
