package poo;

public class Main {
    public static void main(String[] args) {
        Persona persona1 = new Persona();
        Persona persona2 = new Persona("Aladino",23,"201131901");
        Persona persona3 = new Persona("Aladino",23,"201131901", 73.4, 1.74);
        System.out.println(persona3.toString()+", Mayor de edad: "+ persona3.esMayorDeEdad() +", IMC:"+persona3.calcularImc());
    }
}
