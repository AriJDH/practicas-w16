package poo.productos;

public class Parecedero extends Producto{
    private int diasPorCaducar;

    public Parecedero(String nombre, double precio, int diasPordCaducar) {
        super(nombre, precio);
        this.diasPorCaducar = diasPordCaducar;
    }

    public int getDiasPorCaducar() {
        return diasPorCaducar;
    }

    public void setDiasPorCaducar(int diasPordCaducar) {
        this.diasPorCaducar = diasPordCaducar;
    }

    @Override
    public String toString() {
        return "Parecedero{" +
                "diasPordCaducar=" + diasPorCaducar +
                "precio= " + getPrecio()+
                '}';
    }

    @Override
    public double calcular(int cantidadDeProductos) {
        double precio = getPrecio() * cantidadDeProductos;
        return precio - (precio * calcularDescuento(diasPorCaducar));
    }

    private static double calcularDescuento(int diasPorCaducar) {
        if (diasPorCaducar == 1) {
            return 0.8;
        } else if (diasPorCaducar == 2) {
            return 0.6;
        } else if (diasPorCaducar == 3) {
            return 0.5;
        } else {
            return 0;
        }
    }
}
