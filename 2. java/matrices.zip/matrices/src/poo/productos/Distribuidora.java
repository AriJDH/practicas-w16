package poo.productos;

import java.util.ArrayList;
import java.util.List;

public class Distribuidora {
    public static void main(String[] args) {
        List<Producto> productos = new ArrayList<>();
        productos.add(new Parecedero("Galletas",1990, 1));
        productos.add(new NoPerecedero("Fideos", 2000, "pastas"));
        productos.add(new Parecedero("Leche", 1100, 2));
        productos.add(new Parecedero("Yogurth", 750, 4));
        productos.add(new NoPerecedero("Arroz", 2500, "cereal"));
        for (Producto producto: productos) {
            System.out.println("Precio de 5 items: " +producto.getNombre() +" "+producto.calcular(5));
        }
    }
}
