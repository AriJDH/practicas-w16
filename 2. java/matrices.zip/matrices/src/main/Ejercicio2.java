package main;


import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio2 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        final ArrayList<String> participantes = new ArrayList<>();
        int opcion;
        do {
            System.out.println("-------------\t Seleccione \t-------------");
            System.out.println("1)\tInscribir participante.");
            System.out.println("2)\tListar participantes.");
            System.out.println("3)\tDesenscribir participante.");
            System.out.println("4)\tDeterminar el monto a abonar.");
            System.out.println("0)\tSalir");
            opcion = s.nextInt();
            switch (opcion) {
                case 1:
                    System.out.println("Ingrese nombre participante");
                    participantes.add(s.next());
                    break;
                case 2:
                    mostrarParticipantes(participantes);
                    break;
                case 3:
                    eliminarParticipante(participantes, s.next());
                    break;
            }
        } while (opcion != 0);
    }

    static public void mostrarParticipantes(ArrayList<String> participantes) {
        System.out.println("-------------\t Lista Partipantes \t-------------");
        for (int i = 0; i < participantes.size(); i++) {
            System.out.println((i+1)+")\t"+participantes.get(i));
        }
        System.out.println("-------------\t XXXXXXXXXXXXXXXX\t-------------");
    }

    static public void eliminarParticipante(ArrayList<String> participantes,String participante) {
        participantes.remove(participante);
    }
}
