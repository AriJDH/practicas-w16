package Ejercicio_2.interfaces;

public interface IDocumento<T> {
    public void imprimir(T obj);
}
