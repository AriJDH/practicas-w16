package Ejercicio_2.clases;

import Ejercicio_2.interfaces.IDocumento;

public class Informes implements IDocumento<Informes> {
    private String autor;
    private String text;
    private int paginas;
    private String revisor;


    public Informes(String autor, String text, int paginas, String revisor) {
        this.autor = autor;
        this.text = text;
        this.paginas = paginas;
        this.revisor = revisor;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public int getPaginas() {
        return paginas;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }

    public String getRevisor() {
        return revisor;
    }

    public void setRevisor(String revisor) {
        this.revisor = revisor;
    }

    @Override
    public void imprimir(Informes documento){
        System.out.println("Imprimiendo informe");
        System.out.println("Autor: "+ documento.getAutor());
        System.out.println("Texto: "+ documento.getText());
        System.out.println("Paginas: "+documento.getPaginas());
        System.out.println("Revisor: "+ documento.getRevisor());
    }
}
