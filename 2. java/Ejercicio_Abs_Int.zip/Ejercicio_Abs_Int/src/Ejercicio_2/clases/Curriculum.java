package Ejercicio_2.clases;

import Ejercicio_2.interfaces.IDocumento;

import java.util.List;

public class Curriculum implements IDocumento<Curriculum> {
    private Persona persona;
    private List<String> habilidades;

    public Curriculum(Persona persona, List<String> habilidades) {
        this.persona = persona;
        this.habilidades = habilidades;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public List<String> getHabilidades() {
        return habilidades;
    }

    public void setHabilidades(List<String> habilidades) {
        this.habilidades = habilidades;
    }

    @Override
    public void imprimir(Curriculum documento) {
        Persona persona1 = documento.getPersona();
        System.out.println("Imprimiendo curriculum");
        System.out.println("Nombre: "+ persona1.getNombre());
        System.out.println("Apellido: "+ persona1.getApellido());
        System.out.println("Edad: "+ persona1.getEdad());
        System.out.println("Correo: "+persona1.getCorreo());
        System.out.println("Habilidades:");
        for (String habilidad: documento.getHabilidades()){
            System.out.println(habilidad);
        }
    }
}
