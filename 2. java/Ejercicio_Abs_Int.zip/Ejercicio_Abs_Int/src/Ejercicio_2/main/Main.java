package Ejercicio_2.main;

import Ejercicio_2.clases.Curriculum;
import Ejercicio_2.clases.Informes;
import Ejercicio_2.clases.Pdf;
import Ejercicio_2.clases.Persona;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Pdf pdf = new Pdf(12,"Aladino", "Aladdin", "Magico");
        Persona persona = new Persona("Aladino", "Ponce", 23, "aladino.ponce@mercadolibre.cl");
        List<String> habilidades = new ArrayList<>();
        habilidades.add("Programar");
        Curriculum curriculum = new Curriculum(persona,habilidades);
        Informes informes = new Informes("Aladino Ponce", "Este es el informe", 1, "Messi");
        pdf.imprimir(pdf);
        curriculum.imprimir(curriculum);
        informes.imprimir(informes);
    }
}
