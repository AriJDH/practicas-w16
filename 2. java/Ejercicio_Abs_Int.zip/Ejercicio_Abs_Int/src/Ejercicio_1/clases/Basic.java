package Ejercicio_1.clases;

public class Basic extends Cobrador {

    public Basic() {
        super();
    }

    @Override
    public void consultaSaldo() {
        if (testTransaction()) {
            transaccionOK();
            System.out.println("Consultando Saldo");
        } else {
            transaccionNOK();
        }

    }


    public void pagarServicio() {
        if (testTransaction()){
            transaccionOK();
            System.out.println("Pagando Servicio");
        } else {
            transaccionNOK();
        }

    }

    @Override
    public void retiroEfectivo() {
       if (testTransaction()) {
           transaccionOK();
           System.out.println("Retirando Efectivo");
       } else {
           transaccionNOK();
       }
    }
}
