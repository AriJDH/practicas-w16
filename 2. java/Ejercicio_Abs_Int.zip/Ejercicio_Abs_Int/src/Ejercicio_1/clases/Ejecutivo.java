package Ejercicio_1.clases;

import Ejercicio_1.interfaz.IEjecutivo;

public class Ejecutivo extends Transaccion implements IEjecutivo {

    public Ejecutivo() {
        super();
    }

    @Override
    public void realizarDeposito() {

        if (testTransaction()){
            transaccionOK();
            System.out.println("Realizando Deposito");
        } else {
            transaccionNOK();
        }
    }

    @Override
    public void transferencia() {
        if (testTransaction()) {
            transaccionOK();
            System.out.println("Realizando transferencia");
        } else {
            transaccionNOK();
        }
    }
}
