package Ejercicio_1.clases;

import Ejercicio_1.interfaz.ITransaccion;

import java.util.Random;

public class Transaccion implements ITransaccion {

    public Transaccion() {
    }

    @Override
    public void transaccionOK() {
        System.out.println("Transaccion OK");
    }

    @Override
    public void transaccionNOK() {
        System.out.println("Transaccion NOK");
    }

    public boolean testTransaction(){
        Random rd = new Random();
        int random = rd.nextInt(101);
        return random % 2 == 0;
    }
}
