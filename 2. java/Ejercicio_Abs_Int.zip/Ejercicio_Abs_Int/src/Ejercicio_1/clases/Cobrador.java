package Ejercicio_1.clases;

import Ejercicio_1.interfaz.ICobrador;

public class Cobrador extends Transaccion implements ICobrador {

    public Cobrador() {
        super();
    }

    @Override
    public void retiroEfectivo() {
       if (testTransaction()) {
           transaccionOK();
           System.out.println("Retirando Efectivo");
       } else {
           transaccionNOK();
       }
    }

    @Override
    public void consultaSaldo() {
        if (testTransaction()) {
            transaccionOK();
            System.out.println("Consultando Saldo");
        } else {
            transaccionNOK();
        }
    }
}
