package Ejercicio_1.main;

import Ejercicio_1.clases.Basic;
import Ejercicio_1.clases.Cobrador;
import Ejercicio_1.clases.Ejecutivo;

public class Main {
    public static void main(String[] args) {
        Basic basic = new Basic();
        Ejecutivo ejecutivo = new Ejecutivo();
        Cobrador cobrador = new Cobrador();
        basic.consultaSaldo();
        basic.pagarServicio();
        basic.retiroEfectivo();
        ejecutivo.realizarDeposito();
        ejecutivo.transferencia();
        cobrador.consultaSaldo();
        cobrador.retiroEfectivo();;
    }
}
