package Ejercicio_1.interfaz;

public interface IEjecutivo {
    void realizarDeposito();
    void transferencia();
}
