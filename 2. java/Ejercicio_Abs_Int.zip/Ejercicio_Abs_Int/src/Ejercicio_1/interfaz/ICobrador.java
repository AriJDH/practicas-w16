package Ejercicio_1.interfaz;

public interface ICobrador {
    void retiroEfectivo();
    void consultaSaldo();
}
