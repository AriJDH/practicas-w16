package Ejercicio_1.interfaz;

public interface ITransaccion {
    void transaccionOK();
    void transaccionNOK();
}
