package clases;

import java.util.ArrayList;

public class Localizador {

    private Cliente cliente;
    private ArrayList<Reserva> reservas;
    private double total;

    private Paquete paquete;

    public Localizador(Cliente cliente, ArrayList<Reserva> reservas, double total, Paquete paquete) {
        this.cliente = cliente;
        this.reservas = reservas;
        this.total = total;
        this.paquete = paquete;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public ArrayList<Reserva> getReservas() {
        return reservas;
    }

    public void setReservas(ArrayList<Reserva> reservas) {
        this.reservas = reservas;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Paquete getPaquete() {
        return paquete;
    }

    public void setPaquete(Paquete paquete) {
        this.paquete = paquete;
    }

    public void imprimir(){
        System.out.println("Cliente");
        System.out.println(cliente.toString());
        System.out.println("Paquete");
        paquete.getProductos().forEach(System.out::println);
        System.out.println("Reservas");
        reservas.forEach(System.out::println);
        System.out.println("Total");
        System.out.println(total);
    }
}
