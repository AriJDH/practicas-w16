package clases;

import java.util.List;

public class Paquete {
   private List<Productos> productos;

    public Paquete(List<Productos> productos) {
        this.productos = productos;
    }

    public List<Productos> getProductos() {
        return productos;
    }

    public void setProductos(List<Productos> productos) {
        this.productos = productos;
    }

    public boolean isPaqueteCompleto() {
        return productos.size() == 4;
    }

    @Override
    public String toString() {
        return "Paquete{" +
                "productos=" + productos +
                '}';
    }
}
