package main;

import clases.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
    public static ArrayList<Localizador> localizadores = new ArrayList<>();
    public static void main(String[] args) {
        ArrayList<Productos> productos = new ArrayList<>();
        productos.add(new Productos("Hotel"));
        productos.add(new Productos("Comida"));
        productos.add(new Productos("Transporte"));
        productos.add(new Productos("Boleto"));
        Cliente cliente = new Cliente("Aladino",201131901);
        ArrayList<Reserva> reservas = new ArrayList<>();
        reservas.add(new Reserva(new Date(),2000));
        reservas.add(new Reserva(new Date(),2000));
        Paquete paquete = new Paquete(productos);
        double descuento = getDescuento(cliente.getDni(),reservas,paquete);
        double total = getTotal(reservas);
        if (descuento > 0) {
            total = total - (total * descuento);
        }
        Localizador localizador = new Localizador(cliente,reservas,total,paquete);
        localizador.imprimir();
    }

    public static int isAntiguo(int dni){
        return localizadores.stream().filter(localizador -> localizador.getCliente().getDni() == dni).collect(Collectors.toList()).size();
    }

    public static double getDescuento(int dni, ArrayList<Reserva> reservas, Paquete paquete) {
        double descuento = 0;
        if (isAntiguo(dni) > 1) {
            return 0.05;
        } else if (reservas.size() > 1 || reservas.contains("Boleto")) {
            return  0.05;
        } else if (paquete.isPaqueteCompleto()){
            return 0.10;
        }
        else {
            return 0;
        }
    }

    public static List<Localizador> getFiltrado(int dni) {
        return localizadores.stream().filter(localizador -> localizador.getCliente().getDni() == dni).collect(Collectors.toList());
    }

    public static double getTotal(ArrayList<Reserva> reservas){
        double total = 0;
        for (Reserva reserva: reservas){
            total += reserva.getMonto();
        }
        return total;
    }
}
