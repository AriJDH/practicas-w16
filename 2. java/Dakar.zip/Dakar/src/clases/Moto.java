package clases;

public class Moto extends Vehiculo{

}
