package clases;

import java.util.ArrayList;
import java.util.List;

public class Auto extends Vehiculo{

}
