package com.example.be_java_hisp_w16_g09;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeJavaHispW16G09ApplicationTests {

    @Test
    void contextLoads() {
    }

}
