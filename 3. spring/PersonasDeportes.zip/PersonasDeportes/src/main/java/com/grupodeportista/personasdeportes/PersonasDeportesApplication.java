package com.grupodeportista.personasdeportes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonasDeportesApplication {

    public static void main(String[] args) {
        SpringApplication.run(PersonasDeportesApplication.class, args);
    }

}
