package com.grupodeportista.personasdeportes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonasDeportesApplicationTests {

    @Test
    void contextLoads() {
    }

}
