package com.meli.linktracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinktrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
