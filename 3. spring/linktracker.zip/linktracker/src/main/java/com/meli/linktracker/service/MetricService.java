package com.meli.linktracker.service;

import lombok.Data;

@Data

public class MetricService {

}
