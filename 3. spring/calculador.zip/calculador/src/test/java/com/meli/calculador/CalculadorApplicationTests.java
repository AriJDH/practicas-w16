package com.meli.calculador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
