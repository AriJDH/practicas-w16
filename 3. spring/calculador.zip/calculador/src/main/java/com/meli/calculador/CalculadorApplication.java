package com.meli.calculador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculadorApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculadorApplication.class, args);
	}

}
