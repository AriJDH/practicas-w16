package com.example.starwars.exception;

public class NotFoundException extends RuntimeException{
}
