package com.bootcamp.covid.repository;

import com.bootcamp.covid.model.Person;
import org.springframework.data.jpa.repository.JpaRepository;

import javax.persistence.criteria.CriteriaBuilder;
import java.util.List;

public interface PersonRepository extends JpaRepository<Person, Long> {

    List<Person> findAllBySymptomsIsNotNullAndAgeGreaterThan( Integer age );
}
