package com.bootcamp.covid.service;

import com.bootcamp.covid.dto.response.PatientDTO;
import com.bootcamp.covid.dto.SymptomDTO;
import com.bootcamp.covid.dto.request.PersonDTO;

import java.util.List;

public interface ISymptomService {
    List<SymptomDTO> getSymptoms ();
    SymptomDTO getSymptomDTO ( String name );
    List<PatientDTO> getPatients ();

    PersonDTO createPerson(PersonDTO personDTO);
}
