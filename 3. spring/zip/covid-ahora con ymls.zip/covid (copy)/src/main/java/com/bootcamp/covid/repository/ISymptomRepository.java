package com.bootcamp.covid.repository;

import com.bootcamp.covid.model.Person;
import com.bootcamp.covid.model.Symptom;
import org.springframework.data.jpa.repository.JpaRepository;

import javax.swing.text.html.Option;
import java.time.Period;
import java.util.List;
import java.util.Optional;

public interface ISymptomRepository extends JpaRepository<Symptom, Long> {

    Optional<Symptom> findSymptomByName( String name);
}
