package com.bootcamp.covid.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SymptomDTO {
    String code;
    String name;
    String severityLevel;
}
