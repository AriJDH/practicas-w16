package com.bootcamp.covid.dto.response;

import com.bootcamp.covid.dto.SymptomDTO;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class PatientDTO {
    String           name;
    String           lastname;
    List<SymptomDTO> symptoms;
}
