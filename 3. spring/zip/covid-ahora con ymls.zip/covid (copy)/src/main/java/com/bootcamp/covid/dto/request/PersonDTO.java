package com.bootcamp.covid.dto.request;

import com.bootcamp.covid.dto.SymptomDTO;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;

import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
public class PersonDTO {

    @Length(min = 3, max = 30, message = "el nombre no esta en el rango de 3 a 30 caracteres")
    private String name;

    @Length(min = 3, max = 30)
    private String lastName;

    @Email
    @Length(min = 3, max = 30)
    @NotNull
    private String email;

    @Positive
    private Integer age;
}
