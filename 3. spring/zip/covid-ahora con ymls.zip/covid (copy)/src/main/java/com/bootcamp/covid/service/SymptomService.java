package com.bootcamp.covid.service;

import com.bootcamp.covid.dto.response.PatientDTO;
import com.bootcamp.covid.dto.SymptomDTO;
import com.bootcamp.covid.dto.request.PersonDTO;
import com.bootcamp.covid.model.Person;
import com.bootcamp.covid.model.Symptom;
import com.bootcamp.covid.repository.ISymptomRepository;
import com.bootcamp.covid.repository.PersonRepository;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SymptomService implements ISymptomService {

    ISymptomRepository repository;
    PersonRepository   personRepository;
    ModelMapper        mapper;

    public SymptomService ( ISymptomRepository repository, PersonRepository personRepository ) {
        this.repository       = repository;
        this.personRepository = personRepository;
        this.mapper           = new ModelMapper();
    }

    /* Metodos que estarian en el service de Symptoms */
    public List<SymptomDTO> getSymptoms () {
        /* Con las listas tenemos algunos problemas asi que usamos el map de stream para mapear*/
        return repository.findAll()
          .stream()
          .map(symptom -> mapper.map(symptom, SymptomDTO.class))
          .collect(Collectors.toList());
    }

    public SymptomDTO getSymptomDTO ( String name ) {
        Symptom symptom = repository.findSymptomByName(name)
          /*
           * Aca podrian crear una exception personalizada que extienda de RuntiemException
           * por ejemplo: SymptomNotFound
           * pruebenlo para capturar esa exception en el GlobalHandler
           */
          .orElseThrow(() -> new RuntimeException("NOT FOUND"));
        return mapper.map(symptom, SymptomDTO.class);
    }

    /* Metodos que estarian en el service de people */
    public List<PatientDTO> getPatients () {
        List<PatientDTO> patients = personRepository.findAllBySymptomsIsNotNullAndAgeGreaterThan(60)
          .stream()
          .map(riskPerson -> mapper.map(riskPerson, PatientDTO.class))
          .collect(Collectors.toList());
        return patients;
    }

    @Override
    public PersonDTO createPerson ( PersonDTO personDTO ) {
        Person person = mapper.map(personDTO, Person.class);
        personRepository.save(person);
        return personDTO;
    }

}
