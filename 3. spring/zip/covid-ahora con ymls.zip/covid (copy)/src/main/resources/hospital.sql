INSERT INTO person (`id`, `name`, `last_name`, `email`, `age`)
values (1, 'person1', 'lastnam1', 'email1@corre.com', 30),
       (2, 'person2', 'lastnam2', 'email2@corre.com', 40),
       (3, 'person3', 'lastnam3', 'email3@corre.com', 65),
       (4, 'person4', 'lastnam4', 'email4@corre.com', 88);

INSERT INTO symptom (`id`, `code`, `name`, `severity_level`, `id_person`)
values (1, 'S1', 'symtom1', 'LEVE', 1),
       (2, 'S2', 'symtom2', 'LEVE', 2),
       (3, 'S3', 'symtom3', 'LEVE', 3),
       (4, 'S4', 'symtom4', 'LEVE', 4);