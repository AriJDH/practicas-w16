package com.bootcamp.calculadoracalorias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculadoraCaloriasApplicationTests {

    @Test
    void contextLoads() {
    }

}
