package cl.morsecode.cl.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class Ingredientes {
    private String name;
    private Integer calories;

    @Override
    public String toString() {
        return "Ingredientes{" +
                "name='" + name + '\'' +
                ", calories=" + calories +
                '}';
    }
}
