package cl.morsecode.cl.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PlatoDTO {
    private String name;
    private List<String> ingredientes;
    private Integer peso;

    @Override
    public String toString() {
        return "PlatoDTO{" +
                "name='" + name + '\'' +
                ", ingredientes=" + ingredientes +
                ", peso=" + peso +
                '}';
    }
}
