package cl.morsecode.cl.services;

import cl.morsecode.cl.dto.PlatoDTO;
import cl.morsecode.cl.entities.Ingredientes;
import cl.morsecode.cl.entities.Plato;
import cl.morsecode.cl.repositories.IgredientesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class IngredientesServiceImpl implements IngredientesService{

    @Autowired
    private IgredientesRepository igredientesRepository;
    @Override
    public List<Ingredientes> getIngredientes() {
        return igredientesRepository.findAll();
    }

    @Override
    public Ingredientes findMayor() {
        return igredientesRepository.findMayor();
    }

    @Override
    public Ingredientes findIngrediente(String name) {
        return igredientesRepository.findIngrediente(name.toLowerCase());
    }

    @Override
    public Plato addPlato(PlatoDTO platoDTO) {
        Plato plato = new Plato();
        Integer calorias = 0;
        List<Ingredientes> ingredientes = new ArrayList<>();
        for (String nombre: platoDTO.getIngredientes()) {
            Ingredientes ingrediente = igredientesRepository.findIngrediente(nombre.toLowerCase());
            if (ingrediente != null) {
                System.out.println("ingrediente = " + ingrediente);
                ingredientes.add(ingrediente);
                calorias += ingrediente.getCalories();
            }
        }
        plato.setName(platoDTO.getName());
        plato.setCalorias((calorias / 4) * (platoDTO.getPeso() / 10));
        plato.setIngredientes(ingredientes);
        plato.setPeso(platoDTO.getPeso());
        return igredientesRepository.addPlato(plato);
    }

    @Override
    public List<Plato> getPlatos() {
        return igredientesRepository.getPlatos();
    }
}
