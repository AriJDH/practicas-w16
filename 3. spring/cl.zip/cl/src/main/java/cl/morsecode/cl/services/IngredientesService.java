package cl.morsecode.cl.services;

import cl.morsecode.cl.dto.PlatoDTO;
import cl.morsecode.cl.entities.Ingredientes;
import cl.morsecode.cl.entities.Plato;

import java.util.List;

public interface IngredientesService {

    List<Ingredientes> getIngredientes();
    Ingredientes findIngrediente(String name);

    Ingredientes findMayor();

    Plato addPlato(PlatoDTO platoDTO);

    List<Plato> getPlatos();
}
