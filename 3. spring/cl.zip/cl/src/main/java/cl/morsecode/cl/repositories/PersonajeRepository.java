package cl.morsecode.cl.repositories;


import cl.morsecode.cl.dto.PersonajeDTO;

import java.util.List;

public interface PersonajeRepository {
    List<PersonajeDTO> findAllByName(String name);

    List<PersonajeDTO> findPersonajes();
}
