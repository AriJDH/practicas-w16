package cl.morsecode.cl.services;

import cl.morsecode.cl.dto.PersonajeDTO;
import cl.morsecode.cl.entities.starwars.Personaje;
import cl.morsecode.cl.repositories.PersonajeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StarWarsServiceImpl implements StarWarsService{

    @Autowired
    PersonajeRepository personajeRepository;

    @Override
    public List<PersonajeDTO> findPersonaje(String name) {
        return personajeRepository.findAllByName(name);
    }

    @Override
    public List<PersonajeDTO> findAll() {
        return personajeRepository.findPersonajes();
    }
}
