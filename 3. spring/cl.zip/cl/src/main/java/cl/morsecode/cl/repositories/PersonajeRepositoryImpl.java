package cl.morsecode.cl.repositories;

import cl.morsecode.cl.dto.PersonajeDTO;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Repository;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Repository
public class PersonajeRepositoryImpl implements PersonajeRepository{
    private final List<PersonajeDTO> personajes;

    public PersonajeRepositoryImpl() {
        this.personajes = loadPersonajes();
    }

    @Override
    public List<PersonajeDTO> findAllByName(String name) {
        return personajes.stream().filter(personajeDTO -> personajeDTO.getName().startsWith(name)).collect(Collectors.toList());
    }

    @Override
    public List<PersonajeDTO> findPersonajes() {
        return personajes;
    }

    private List<PersonajeDTO> loadPersonajes(){
        File file = new File("./src/main/resources/starwars.json");
        ObjectMapper objectMapper = new ObjectMapper();
        TypeReference<List<PersonajeDTO>> typeRef = new TypeReference<>() {};
        List<PersonajeDTO> characters = null;
        try {
            characters = objectMapper.readValue(file, typeRef);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return characters;
    }

}
