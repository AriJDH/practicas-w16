package cl.morsecode.cl.repositories;

import cl.morsecode.cl.entities.Ingredientes;
import cl.morsecode.cl.entities.Plato;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Repository;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Repository
public class IngredientesRepositoryImpl implements  IgredientesRepository{

    private static List<Ingredientes> ingredientes;
    private static List<Plato> platos;

    public IngredientesRepositoryImpl(){
        ingredientes = getIngredientes();
        platos = new ArrayList<>();
    }

    @Override
    public List<Ingredientes> findAll() {
        return ingredientes;
    }

    @Override
    public Ingredientes findIngrediente(String name) {
        return ingredientes.stream()
                .filter(ingrediente -> ingrediente.getName().toLowerCase().equals(name))
                .findAny()
                .orElse(null);
    }

    @Override
    public Ingredientes findMayor() {
        return ingredientes.stream()
                .max(Comparator.comparing(Ingredientes::getCalories))
                .orElse(null);
    }

    @Override
    public List<Ingredientes> getIngredientes() {
        File file = new File("./src/main/resources/food.json");
        ObjectMapper mapper = new ObjectMapper();
        List<Ingredientes> ingredientes = null;
        try {
            ingredientes = mapper.readValue(file, new TypeReference<List<Ingredientes>>() {});
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return ingredientes;
    }
    public Plato addPlato(Plato plato){
        platos.add(plato);
        return plato;
    }

    @Override
    public List<Plato> getPlatos() {
        return platos;
    }
}
