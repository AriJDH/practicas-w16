package cl.morsecode.cl.repositories;

import cl.morsecode.cl.entities.Ingredientes;
import cl.morsecode.cl.entities.Plato;

import java.util.List;

public interface IgredientesRepository {
    List<Ingredientes> getIngredientes();
    List<Ingredientes> findAll();
    Ingredientes findMayor();
    Ingredientes findIngrediente(String name);
    Plato addPlato(Plato plato);
    List<Plato> getPlatos();
}
