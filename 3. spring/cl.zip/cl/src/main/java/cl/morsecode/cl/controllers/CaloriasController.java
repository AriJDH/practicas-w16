package cl.morsecode.cl.controllers;

import cl.morsecode.cl.dto.PlatoDTO;
import cl.morsecode.cl.services.IngredientesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/calorias")
public class CaloriasController {

    @Autowired
    private IngredientesService ingredientesService;

    @GetMapping
    public ResponseEntity<?> getIngredientes(){
        return new ResponseEntity<>(ingredientesService.getIngredientes(), HttpStatus.OK);
    }

    @GetMapping("/mayor")
    public ResponseEntity<?> findIngrediente(){
        return new ResponseEntity<>(ingredientesService.findMayor(),HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<?> addPlato(@RequestBody PlatoDTO platoDTO) {
        return new ResponseEntity<>(ingredientesService.addPlato(platoDTO),HttpStatus.OK);
    }

    @GetMapping("/platos")
    public ResponseEntity<?> getPlatos() {
        return new ResponseEntity<>(ingredientesService.getPlatos(),HttpStatus.OK);
    }
}
