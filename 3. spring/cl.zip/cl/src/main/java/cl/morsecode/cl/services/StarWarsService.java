package cl.morsecode.cl.services;

import cl.morsecode.cl.dto.PersonajeDTO;
import cl.morsecode.cl.entities.starwars.Personaje;

import java.util.List;

public interface StarWarsService {
    List<PersonajeDTO> findPersonaje(String name);

    List<PersonajeDTO> findAll();
}
