package cl.morsecode.cl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MorsecodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
