package com.blog.blog.controllers;

import com.blog.blog.dto.LinkDTO;
import com.blog.blog.services.ILinkService;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/link")
public class LinkController {

    @Autowired
    private ILinkService linkService;

    @PostMapping
    public ResponseEntity<?> addLink(@RequestBody LinkDTO linkDTO){
        return new ResponseEntity<>(linkService.addLink(linkDTO), HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<?> getLinks() {
        return new ResponseEntity<>(linkService.getLinks(),HttpStatus.OK);
    }

    @GetMapping("/{linkid}")
    public ResponseEntity<String> redireccioner(@PathVariable String linkid) {
        return new ResponseEntity<>("redirect:"+linkService.redireccionar(linkid),HttpStatus.OK);
    }

    @GetMapping("/metrics/{linkid}")
    public ResponseEntity<Integer> getMetrics(@PathVariable String linkid) {
        return new ResponseEntity<>(linkService.getMetrics(linkid), HttpStatus.OK);
    }
}
