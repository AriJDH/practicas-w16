package com.blog.blog.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Link {
    private String id;
    private String url;
    private String password;

    @Override
    public boolean equals(Object o)  {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Link link = (Link) o;
        return id.equals(link.id) && url.equals(link.url) && password.equals(link.password);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, url, password);
    }
}
