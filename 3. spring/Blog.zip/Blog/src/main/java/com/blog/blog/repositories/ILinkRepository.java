package com.blog.blog.repositories;


import com.blog.blog.dto.LinkDTO;
import com.blog.blog.entities.Link;

import java.util.List;
import java.util.Map;

public interface ILinkRepository {
    LinkDTO addLink(Link link);
    List<Link> getLinks();
    Map<String, Integer> getRedireccionar();

    void addRedireccion(String id, Integer cantidad);
}
