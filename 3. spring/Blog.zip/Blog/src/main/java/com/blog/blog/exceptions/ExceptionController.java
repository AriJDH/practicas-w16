package com.blog.blog.exceptions;

import com.blog.blog.dto.ResponseExceptionDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

@ControllerAdvice(annotations = RestController.class)
public class ExceptionController {

    @ExceptionHandler(BadUrlException.class)
    public ResponseEntity<?> badUrl(Exception ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseExceptionDTO(HttpStatus.BAD_REQUEST.value(),"Url invalida"));
    }

    @ExceptionHandler(UrlNotFoundException.class)
    public ResponseEntity<?> urlNotFound(Exception ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ResponseExceptionDTO(HttpStatus.NOT_FOUND.value(), ex.getMessage()));
    }

}
