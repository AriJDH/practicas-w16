package com.blog.blog.services;

import com.blog.blog.dto.LinkDTO;
import com.blog.blog.dto.LinkResponseDTO;
import com.blog.blog.entities.Link;

import java.util.List;

public interface ILinkService {
    LinkResponseDTO addLink(LinkDTO link);
    List<Link> getLinks();

    String redireccionar(String id);

    Integer getMetrics(String id);

}
