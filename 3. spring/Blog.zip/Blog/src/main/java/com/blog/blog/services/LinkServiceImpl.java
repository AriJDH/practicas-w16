package com.blog.blog.services;

import com.blog.blog.dto.LinkDTO;
import com.blog.blog.dto.LinkResponseDTO;
import com.blog.blog.entities.Link;
import com.blog.blog.exceptions.BadUrlException;
import com.blog.blog.exceptions.UrlNotFoundException;
import com.blog.blog.repositories.ILinkRepository;
import org.apache.commons.validator.routines.UrlValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class LinkServiceImpl implements ILinkService{

    @Autowired
    ILinkRepository linkRepository;

    @Override
    public LinkResponseDTO addLink(LinkDTO link) {
        UUID uuid = UUID.randomUUID();
        if (!validateUrl(link.getUrl())) {
            throw new BadUrlException("Url es invalida");
        }
        LinkResponseDTO responseDTO = new LinkResponseDTO(uuid.toString());
        linkRepository.addLink(new Link(responseDTO.getId(),link.getUrl(),""));
        return responseDTO;
    }

    @Override
    public List<Link> getLinks() {
        return linkRepository.getLinks();
    }

    @Override
    public String redireccionar(String id) {
        List<Link> links = this.getLinks();
        Link url = links.stream()
                    .filter(link -> link.getId().equals(id))
                    .findAny()
                    .orElseThrow(() -> new UrlNotFoundException("No existe tal URL"));
        Map<String, Integer> redirecciones = linkRepository.getRedireccionar();
        Integer cantidad = redirecciones.getOrDefault(url.getUrl(), 0);
        linkRepository.addRedireccion(url.getUrl(), cantidad+1);
        return url.getUrl();
    }

    @Override
    public Integer getMetrics(String id) {
        List<Link> links = this.getLinks();
        Link url = links.stream()
                .filter(link -> link.getId().equals(id))
                .findAny()
                .orElseThrow(() -> new UrlNotFoundException("No existe tal URL"));
        return linkRepository.getRedireccionar().getOrDefault(url.getUrl(),0);
    }

    public static boolean validateUrl(String url) {
        UrlValidator urlValidator = new UrlValidator();
        return urlValidator.isValid(url);
    }


}
