package com.blog.blog.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
public class ResponseExceptionDTO {
    private Date fecha;
    private int status;
    private String mensaje;

    public ResponseExceptionDTO(int status, String mensaje) {
        this.fecha = new Date();
        this.status = status;
        this.mensaje = mensaje;
    }
}
