package com.blog.blog.repositories;

import com.blog.blog.dto.LinkDTO;
import com.blog.blog.entities.Link;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class LinkRepositoryImpl implements ILinkRepository{

    private Map<String, Integer> cantidades = new HashMap<>();
    private List<Link> links =  new ArrayList<>();

    @Override
    public LinkDTO addLink(Link link) {
        LinkDTO linkDTO = new LinkDTO(link.getUrl());
        links.add(link);
        cantidades.put(link.getId(),1);
        return linkDTO;
    }

    @Override
    public List<Link> getLinks() {
        return links;
    }

    @Override
    public Map<String, Integer> getRedireccionar() {
        return cantidades;
    }

    @Override
    public void addRedireccion(String id, Integer cantidad) {
        cantidades.put(id, cantidad);
    }

}
