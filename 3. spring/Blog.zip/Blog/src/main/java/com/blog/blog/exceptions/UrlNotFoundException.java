package com.blog.blog.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "No existe url con ese id")
public class UrlNotFoundException extends RuntimeException{

    public UrlNotFoundException() {
    }

    public UrlNotFoundException(String message) {
        super(message);
    }
}
