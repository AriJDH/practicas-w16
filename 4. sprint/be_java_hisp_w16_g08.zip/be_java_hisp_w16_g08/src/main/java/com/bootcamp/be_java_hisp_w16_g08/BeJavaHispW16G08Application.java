package com.bootcamp.be_java_hisp_w16_g08;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeJavaHispW16G08Application {
	public static void main(String[] args) {
		SpringApplication.run(BeJavaHispW16G08Application.class, args);
	}


}
