package com.bootcamp.be_java_hisp_w16_g08;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeJavaHispW16G08ApplicationTests {

	@Test
	void contextLoads() {
	}

}
