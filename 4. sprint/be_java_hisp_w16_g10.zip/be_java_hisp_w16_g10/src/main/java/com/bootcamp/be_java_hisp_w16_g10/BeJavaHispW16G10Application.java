package com.bootcamp.be_java_hisp_w16_g10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeJavaHispW16G10Application {

    public static void main(String[] args) {
        SpringApplication.run(BeJavaHispW16G10Application.class, args);
    }

}
