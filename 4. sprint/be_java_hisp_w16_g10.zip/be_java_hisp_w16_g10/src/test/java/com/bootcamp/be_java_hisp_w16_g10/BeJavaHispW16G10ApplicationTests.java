package com.bootcamp.be_java_hisp_w16_g10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeJavaHispW16G10ApplicationTests {

    @Test
    void contextLoads() {
    }

}
