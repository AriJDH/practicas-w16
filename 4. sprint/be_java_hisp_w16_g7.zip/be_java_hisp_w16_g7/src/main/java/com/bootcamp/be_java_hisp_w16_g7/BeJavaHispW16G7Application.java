package com.bootcamp.be_java_hisp_w16_g7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeJavaHispW16G7Application {

    public static void main(String[] args) {
        SpringApplication.run(BeJavaHispW16G7Application.class, args);
    }

}
