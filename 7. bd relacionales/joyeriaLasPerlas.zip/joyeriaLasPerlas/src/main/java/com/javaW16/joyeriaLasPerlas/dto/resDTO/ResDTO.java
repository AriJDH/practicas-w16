package com.javaW16.joyeriaLasPerlas.dto.resDTO;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor

public class ResDTO {
   String message;
}
