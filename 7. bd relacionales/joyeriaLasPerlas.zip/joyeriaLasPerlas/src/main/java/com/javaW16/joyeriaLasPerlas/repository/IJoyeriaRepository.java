package com.javaW16.joyeriaLasPerlas.repository;

import com.javaW16.joyeriaLasPerlas.model.Joya;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IJoyeriaRepository extends JpaRepository < Joya , Long > {

}
