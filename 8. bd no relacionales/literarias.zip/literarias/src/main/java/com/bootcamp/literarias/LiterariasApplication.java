package com.bootcamp.literarias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiterariasApplication {

	public static void main(String[] args) {
		SpringApplication.run(LiterariasApplication.class, args);
	}

}
