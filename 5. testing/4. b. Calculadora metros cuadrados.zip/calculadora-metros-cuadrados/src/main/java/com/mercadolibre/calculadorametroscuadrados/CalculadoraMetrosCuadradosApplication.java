package com.mercadolibre.calculadorametroscuadrados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculadoraMetrosCuadradosApplication {
  public static void main(String[] args) {
    SpringApplication.run(CalculadoraMetrosCuadradosApplication.class, args);
  }
}
