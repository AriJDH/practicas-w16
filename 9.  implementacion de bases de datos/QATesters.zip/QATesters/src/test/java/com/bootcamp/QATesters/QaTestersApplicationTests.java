package com.bootcamp.QATesters;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QaTestersApplicationTests {

	@Test
	void contextLoads() {
	}

}
