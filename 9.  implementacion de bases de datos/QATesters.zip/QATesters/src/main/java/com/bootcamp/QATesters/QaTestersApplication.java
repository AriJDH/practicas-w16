package com.bootcamp.QATesters;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QaTestersApplication {

	public static void main(String[] args) {
		SpringApplication.run(QaTestersApplication.class, args);
	}

}
