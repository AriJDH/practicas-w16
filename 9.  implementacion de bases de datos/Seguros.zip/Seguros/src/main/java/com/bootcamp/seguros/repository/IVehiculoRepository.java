package com.bootcamp.seguros.repository;

import com.bootcamp.seguros.model.Vehiculo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IVehiculoRepository extends JpaRepository<Vehiculo,Long> {
    @Query("SELECT v FROM Vehiculo v")
    List<Vehiculo> getAllVehiculos();

    @Query("SELECT v.marca,v.patente FROM Vehiculo v ORDER BY v.anioFabricacion ASC")
    List<String> getAllPatentesYMarcasVehiculos();

    @Query("SELECT v.patente FROM Vehiculo v where v.cantidadRuedas>4 AND extract(YEAR from v.anioFabricacion) = extract(YEAR FROM current_date )")
    List<String> getAllPatentesVehiculosFabricadosAnioCorrienteYMasDeCuatroRuedas();

}
