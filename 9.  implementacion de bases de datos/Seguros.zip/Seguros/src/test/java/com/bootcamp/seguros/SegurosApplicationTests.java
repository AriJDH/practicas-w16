package com.bootcamp.seguros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SegurosApplicationTests {

    @Test
    void contextLoads() {
    }

}
