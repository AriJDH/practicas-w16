package com.bootcamp.joyeria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoyeriaApplication {

    public static void main(String[] args) {
        SpringApplication.run(JoyeriaApplication.class, args);
    }

}
