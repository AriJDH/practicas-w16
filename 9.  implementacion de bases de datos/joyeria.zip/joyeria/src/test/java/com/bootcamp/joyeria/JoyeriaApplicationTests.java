package com.bootcamp.joyeria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoyeriaApplicationTests {

    @Test
    void contextLoads() {
    }

}
