package com.bootcamp.aplicationdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AplicationdbApplication {

	public static void main(String[] args) {
		SpringApplication.run(AplicationdbApplication.class, args);
	}

}
