package com.bootcamp.aplicationdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AplicationdbApplicationTests {

	@Test
	void contextLoads() {
	}

}
