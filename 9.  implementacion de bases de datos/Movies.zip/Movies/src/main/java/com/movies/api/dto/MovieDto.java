package com.movies.api.dto;

public class MovieDto {

    private String title;
}
