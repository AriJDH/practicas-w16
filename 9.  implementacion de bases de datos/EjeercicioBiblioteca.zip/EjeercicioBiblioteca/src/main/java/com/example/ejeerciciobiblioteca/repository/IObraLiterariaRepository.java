package com.example.ejeerciciobiblioteca.repository;

import com.example.ejeerciciobiblioteca.entity.ObraLiteraria;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IObraLiterariaRepository extends ElasticsearchRepository<ObraLiteraria,String> {
}
