package com.example.ejeerciciobiblioteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjeercicioBibliotecaApplication {

    public static void main(String[] args) {
        SpringApplication.run(EjeercicioBibliotecaApplication.class, args);
    }

}
