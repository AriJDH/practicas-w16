package com.example.ejeerciciobiblioteca.controller;


import com.example.ejeerciciobiblioteca.dto.ObraLiterariaDto;
import com.example.ejeerciciobiblioteca.entity.ObraLiteraria;
import com.example.ejeerciciobiblioteca.service.IObraLiterariaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ObraLiterariaRestController {

    @Autowired
    IObraLiterariaService obraLiterariaService;

    @PostMapping("/obraLiteraria")
    public ResponseEntity<?> createObraLiteraria(@RequestBody ObraLiterariaDto obra){
        obraLiterariaService.createObraLiteraria(obra);
        return ResponseEntity.ok().body(null);
    }

    @GetMapping("/obrasLiterarias")
    public ResponseEntity<List<ObraLiterariaDto>> getAllObraLiterarias(){
        return ResponseEntity.ok(obraLiterariaService.getAllObraLiterarias());
    }
}
