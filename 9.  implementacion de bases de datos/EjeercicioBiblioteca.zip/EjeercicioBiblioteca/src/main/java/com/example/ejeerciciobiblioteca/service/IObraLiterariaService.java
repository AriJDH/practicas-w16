package com.example.ejeerciciobiblioteca.service;

import com.example.ejeerciciobiblioteca.dto.ObraLiterariaDto;
import com.example.ejeerciciobiblioteca.entity.ObraLiteraria;

import java.util.List;

public interface IObraLiterariaService {

    void createObraLiteraria(ObraLiterariaDto obra);

    List<ObraLiterariaDto> getAllObraLiterarias();
}
