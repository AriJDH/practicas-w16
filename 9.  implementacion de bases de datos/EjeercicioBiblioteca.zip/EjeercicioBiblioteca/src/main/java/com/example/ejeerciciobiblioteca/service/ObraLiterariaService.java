package com.example.ejeerciciobiblioteca.service;


import com.example.ejeerciciobiblioteca.dto.ObraLiterariaDto;
import com.example.ejeerciciobiblioteca.entity.ObraLiteraria;
import com.example.ejeerciciobiblioteca.repository.IObraLiterariaRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ObraLiterariaService implements IObraLiterariaService {

    @Autowired
    IObraLiterariaRepository obraRepository;

    ObjectMapper mapper = new ObjectMapper();

    @Override
    public void createObraLiteraria(ObraLiterariaDto obra) {
        ObraLiteraria nuevaObra = mapper.convertValue(obra,ObraLiteraria.class);
        obraRepository.save(nuevaObra);
    }

    @Override
    public List<ObraLiterariaDto> getAllObraLiterarias() {
        List<ObraLiterariaDto> returnList = new ArrayList<>();
        obraRepository.findAll().forEach(x->returnList.add(mapper.convertValue(x,ObraLiterariaDto.class)));
        return returnList;
    }


}
