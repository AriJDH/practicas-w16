package com.example.lasperlas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LasPerlasApplication {

	public static void main(String[] args) {
		SpringApplication.run(LasPerlasApplication.class, args);
	}

}
