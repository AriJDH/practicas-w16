package com.example.lasperlas.repository;

public class RepositoryJoya {
}
