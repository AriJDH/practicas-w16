package com.example.ejerciciodosvivo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioDosVivoApplication {

    public static void main(String[] args) {
        SpringApplication.run(EjercicioDosVivoApplication.class, args);
    }

}
