package com.example.ejerciciodosvivo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioDosVivoApplicationTests {

    @Test
    void contextLoads() {
    }

}
