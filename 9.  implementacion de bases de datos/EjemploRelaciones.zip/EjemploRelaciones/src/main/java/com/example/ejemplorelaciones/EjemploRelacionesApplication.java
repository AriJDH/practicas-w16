package com.example.ejemplorelaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploRelacionesApplication {

    public static void main(String[] args) {
        SpringApplication.run(EjemploRelacionesApplication.class, args);
    }

}
