package com.example.ejerciciomovie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioMovieApplication {

    public static void main(String[] args) {
        SpringApplication.run(EjercicioMovieApplication.class, args);
    }

}
