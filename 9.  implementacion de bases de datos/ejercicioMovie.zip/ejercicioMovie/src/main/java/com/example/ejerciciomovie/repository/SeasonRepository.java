package com.example.ejerciciomovie.repository;

import com.example.ejerciciomovie.entity.Season;
import com.example.ejerciciomovie.entity.Serie;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SeasonRepository  extends JpaRepository<Season,Long> {
}
