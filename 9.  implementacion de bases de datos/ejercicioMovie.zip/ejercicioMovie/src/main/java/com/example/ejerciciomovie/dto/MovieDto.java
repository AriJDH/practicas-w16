package com.example.ejerciciomovie.dto;

public class MovieDto {

    private String title;
}

