package com.bootcamp.movieshql.service;

public interface ISerieService {
}
