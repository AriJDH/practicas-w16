package com.bootcamp.movieshql.service;

public class SerieServiceImpl implements ISerieService{
}
