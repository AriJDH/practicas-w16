package com.bootcamp.movieshql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesHqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
