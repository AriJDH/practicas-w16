package com.bootcamp.qatester;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QaTesterApplication {

    public static void main(String[] args) {
        SpringApplication.run(QaTesterApplication.class, args);
    }

}
