package com.bootcamp.qatester;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QaTesterApplicationTests {

    @Test
    void contextLoads() {
    }

}
